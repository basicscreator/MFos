@echo off
mode con: cols=111 lines=31
chcp 65001
if exist MF.txt goto home
echo Setting Up MFos...
echo quack! > MF.txt
ping localhost -n 5 >nul
echo Loading MFos...
ping localhost -n 5 >nul
color 0f
:home
call C.bat
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Welcome│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo Type help or h or ? for the comands list                                                        
echo.                                                                                                                      
echo.                                                                                                                      
echo. 
echo. 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                     
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                     
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo VERSION: 1.0 BETA
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input4= └→
if %input4% ==help goto H
if %input4% ==h goto H
if %input4% ==? goto H
if %input4% ==imp goto I
if %input4% ==calc goto C
if %input4% ==txt goto T
if %input4% ==file goto F
if %input4% ==game goto G
if %input4% ==cmd goto CM
if %input4% ==exi goto E
if %input4% ==mfws goto M
goto home

:E 
cls 
color 0c
echo You are about to shut of the system.
echo.
choice /c YN /m "Continue?"
if errorlevel 2 goto home
if errorlevel 1 exit

:CM
cls 
color 0c
echo You are about to enter in cmd mode, to ext cmd mote type "exit"
echo.
choice /c YN /m "Continue?"
if errorlevel 2 goto home
if errorlevel 1 cmd

:gugugaga
goto home

:G
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Games │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Choose how you want to entertain yourself
echo.
echo 1.Guess the number 
echo 2.Quiz 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                             ██████████
echo.                                                                                          ████░██████░████
echo.                                                                                         ███░██████████░███
echo.                                                                                         ██░█░████████░█░██
echo.                                                                                         ███░██      ██░███
echo.                                                                                         ████          ████
echo.                                                                                         █░░█          █░░█
echo.                                                                                         ████          ████
echo.                                                                                          ██            ██
echo.                                                                                                                      
echo.                                                                                                                      
echo Press "e" to go to the home screen
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input17= └→
if %input17% ==1 goto IN
if %input17% ==2 goto QZ
if %input17% ==e goto home


:QZ
set punteggio=0
:inizio
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Quiz │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.

REM Domanda 1
echo 1) What's the American capital?
echo A) Chicago
echo B) Washington DC
echo C) New York
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 2
echo.
echo 2) What is 5x5?
echo A) 20
echo B) 15
echo C) 25
set /p risposta=
if /i "%risposta%"=="C" set /a punteggio+=1

REM Domanda 3
echo.
echo 3) Whats the color of the sky?
echo A) Blue
echo B) Green
echo C) Red
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 4
echo.
echo 4) How many days are in a week?
echo A) 5
echo B) 7
echo C) 10
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 5
echo.
echo 5) Whats a programming language?
echo A) Python
echo B) Windows
echo C) HTML
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 6
echo.
echo 6) 10 / 2 = ?
echo A) 2
echo B) 10
echo C) 5
set /p risposta=
if /i "%risposta%"=="C" set /a punteggio+=1

REM Domanda 7
echo.
echo 7) The sun its a...
echo A) Star
echo B) Planet
echo C) Comet
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 8
echo.
echo 8) Whats the opposite of "high"?
echo A) Small
echo B) Large
echo C) Long
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 9
echo.
echo 9) How many months are in a year?
echo A) 10
echo B) 12
echo C) 14
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 10
echo.
echo 10) Which animal barks?
echo A) Cat
echo B) Dog
echo C) Fish
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

cls
echo ============================
echo        RESULTS
echo ============================
echo.
echo You did %punteggio% out of 10!

if %punteggio% GEQ 8 (
    echo Gg! 
) else if %punteggio% GEQ 5 (
    echo Thats good! 
) else (
    echo Try again! 
)

echo.
choice /c YN /m "Wanna retry?"
if errorlevel 2 goto G
if errorlevel 1 goto QZ

:IN
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Guess the number  │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.
set /a numero=%random% %% 10 + 1
set tentativi=0

:gioca
set /a tentativi+=1
echo.
set /p scelta=Type a number from 1 to 10: 

if %scelta% LSS %numero% (
    echo Too low!
    goto gioca
)

if %scelta% GTR %numero% (
    echo Too high!
    goto gioca
)

echo.
echo You did it!
echo Number: %numero%
echo Attempts: %tentativi%

echo.
choice /c SN /m "Try again??"
if errorlevel 2 goto G
if errorlevel 1 goto IN

:F
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Files Manager │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛ 
echo.                                                      
echo -----------------------------------------------------------------------------------------------------------------------
echo Navigation Instructions: At the top left you can see the directory you are currently in (Ex. "C:\Users\User\Desktop\MFos"). Below that, you can see the folders in the current directory (for example: if you are on the desktop and there is a folder called "Folder" on your desktop, you will see Folder inside Desktop, as if it were its own root). Under the list of folders, you can see the list of files contained in the first folder (the one at the top) (Ex. if you are on the desktop, you will see all the files on the desktop). Finally, if you want to change the directory, you can type "cd" followed by the name of the folder you want to go to. However, you can only navigate into folders that exist within your current directory. So if you want to go back one folder, you need to type cd .. (Ex. if the directory is C:\Users\User\Desktop and you want to go to MFos, which is inside Desktop, you type cd MFos. But if you want to go to User, which contains Desktop, then you type cd ..).
echo.
echo Editing Instructions: If you want to create a file, type "echo (content) > (name).(file type)". If you want to delete a file, type "del (name).(file type)". If you want to open one, type "call (name).(file type)".
echo.
echo type "goto home" to go to the home page
echo -----------------------------------------------------------------------------------------------------------------------
echo Directory: %cd%
echo.
tree
echo.                                                                                                              
dir                                                                                                                      
echo.                                                                                                                      
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input16= └→
%input16%
goto F

:H
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - HELP│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo COMANDS LIST                                                        
echo -imp            .Settings 
echo -calc           .Calculator 
echo -txt            .Notepad
echo -file           .Files Manager
echo -game           .Giochi
echo -cmd            .Cmd
echo -help/h/?       .Comands List
echo -exit           .Exit
echo -mfws           .MFwebsearch
echo.                                                                                                                      
echo.                                                                                                ████████████
echo.                                                                                              ████████████████
echo.                                                                                             ████          ████
echo.                                                                                            ████            ████
echo.                                                                                            ████            ████
echo.                                                                                                          ████
echo.                                                                                                         ████
echo.                                                                                                       ████
echo.                                                                                                    ██████
echo.                                                                                                   ████
echo.                                                                                                   ████
echo.                                                                                                   ████
echo.
echo.                                                                                                   ████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p inputP= └→
goto home

:T
call C.bat
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Choose between:
echo.
echo 1 - Write 
echo 2 - Read
echo 3 - Look for text files 
echo.
echo Type "e" to go to the home page
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input13= └→
if "%input13%"=="1" goto scrivi
if "%input13%"=="2" goto leggi
if "%input13%"=="3" goto vedi
if "%input13%"=="e" goto home
goto T

:vedi
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
dir *.txt /b
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input15= └→
goto T

:scrivi
cls
setlocal EnableDelayedExpansion
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Type the file name (Without .txt)
echo.
echo.  
echo.  
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set /p nomefile= └→
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo File Name: %nomefile%
echo.
echo Now write the content, when you are done type FINE.  
echo.  
> "%nomefile%.txt" (
    rem crea il file vuoto
)

:loop
set /p riga=
if "!riga!"=="FINE" goto salva
echo !riga!>>"%nomefile%.txt"
goto loop

:salva
endlocal
echo.
echo File "%nomefile%.txt" Saved!
pause
goto T

:leggi
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Type the file name (Without .txt)
echo.
echo Type "e" to go to the home page
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set /p nomefile2=
if not exist "%nomefile2%.txt" (
    echo.
    echo [38;2;255;0;0mERROR: File not found![0m
    pause
    goto T
)

cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
type "%nomefile2%.txt"
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input14= └→
goto T

:C
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Calculator │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Type an equation with + - / *
echo.                                                                                                                      
echo. 
echo. 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                            █████████
echo.
echo.                                                                                            ███ ███
echo.                                                                                              ███
echo.                                                                                            ███ ███       ██████
echo.                                                                                                          ██████
echo.                                                                                                          ██████
echo.                                                                                                    ██████████████████
echo.                                                                                                    ██████████████████
echo.                                                                                                          ██████
echo.                                                                                          ███             ██████
echo.                                                                                         ███              ██████
echo.                                                                                        ███
echo Press enter to view the last equation you did                                          ███
echo Type "e" to go to the home page
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input11= └→
if %input11% ==e goto home
set/a calc= %input11%
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Calculator │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Equation: %input11%
echo Result: %calc%
echo. 
echo. 
echo.
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                            █████████
echo.
echo.                                                                                            ███ ███
echo.                                                                                              ███
echo.                                                                                            ███ ███       ██████
echo.                                                                                                          ██████
echo.                                                                                                          ██████
echo.                                                                                                    ██████████████████
echo.                                                                                                    ██████████████████
echo.                                                                                                          ██████
echo.                                                                                          ███             ██████
echo.                                                                                         ███              ██████
echo.                                                                                        ███
echo.                                                                                       ███
echo Press enter
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input12= └→
goto C

:M
color 0f
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - MF Web Search│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo Type "e" to go to the home page
echo.
echo.
echo.
echo.
echo                           [38;2;255;0;0m████            ████   ████████████████████████████████████████████████
echo                           [38;2;255;165;0m████████    ████████   ████████████████████████████████████████████████
echo                           [38;2;255;255;0m████████    ████████   ████
echo                           [38;2;0;255;0m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;255;255m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;0;255m████            ████   ████
echo                           [38;2;255;0;255m████            ████   ████    [38;2;0;255;255m████            ████    [38;2;255;255;0m████████████████
echo                           [38;2;0;0;255m████            ████   ████     [38;2;0;255;255m████          ████     [38;2;255;255;0m████
echo                           [38;2;0;255;255m████            ████   ████      [38;2;0;255;255m████  ████  ████      [38;2;255;255;0m████████████████
echo                           [38;2;0;255;0m████            ████   ████       [38;2;0;255;255m██████████████                   [38;2;255;255;0m████
echo                           [38;2;255;255;0m████            ████   ████        [38;2;0;255;255m████    ████        [38;2;255;255;0m████████████████
echo.
echo                            [38;2;255;255;0m███ ███ ███ █   ███ ███ ███    █  █   [38;2;0;255;255m█ █  █ ███ ██ ███ █  █ ███ ███
echo                            [38;2;255;255;0m█   █   █ █ █   █ █ █ █ █ █    █  █   [38;2;0;255;255m█ ██ █  █  █  █ █ ██ █ █    █
echo                            [38;2;255;255;0m███ ███ ███ █   █ █ ███ █ █    █      [38;2;0;255;255m█ █ ██  █  ██ ███ █ ██ ███  █
echo                            [38;2;255;255;0m█     █ █   █   █ █ ██  ███    █      [38;2;0;255;255m█ █  █  █  █  ██  █  █ █    █
echo                            [38;2;255;255;0m███ ███ █   ███ ███ █ █ █ █    ███    [38;2;0;255;255m█ █  █  █  ██ █ █ █  █ ███  █ [0m
echo.
echo Type the address of the [38;2;0;255;255mWeb Site[0m and [38;2;255;255;0mExplore[0m the world of the [38;2;0;255;255minternet![0m [38;2;255;0;0m(ATTENTION, THE ADDRESS HAS TO START WITH https://)[0m
echo.
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input9= └→
if %input9% ==e goto home

:ananananana
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - MF Web Search│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo --- MFWS - Powered By : Any Browser Your Device Uses ------------------------------------------------------------------
echo.
echo.  
echo If the link is underlined then it works, if not then it does not work
echo.                                                                                                              
echo.                                                                                                                      
echo Address: %input9% [38;2;255;0;0m(To enter press Ctrl + LMC)[0m 
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.
echo.
echo                           [38;2;255;0;0m████            ████   ████████████████████████████████████████████████
echo                           [38;2;255;165;0m████████    ████████   ████████████████████████████████████████████████
echo                           [38;2;255;255;0m████████    ████████   ████
echo                           [38;2;0;255;0m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;255;255m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;0;255m████            ████   ████
echo                           [38;2;255;0;255m████            ████   ████    [38;2;0;255;255m████            ████    [38;2;255;255;0m████████████████
echo                           [38;2;0;0;255m████            ████   ████     [38;2;0;255;255m████          ████     [38;2;255;255;0m████
echo                           [38;2;0;255;255m████            ████   ████      [38;2;0;255;255m████  ████  ████      [38;2;255;255;0m████████████████
echo                           [38;2;0;255;0m████            ████   ████       [38;2;0;255;255m██████████████                   [38;2;255;255;0m████
echo                           [38;2;255;255;0m████            ████   ████        [38;2;0;255;255m████    ████        [38;2;255;255;0m████████████████[0m
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input10= └→
goto M


:I
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo  SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS - SETTINGS 
echo.
echo DEVICE INFO 1
echo.
echo PERSONALIZATION 2
echo.
echo SYSTEM INFO 3
echo.
echo Type "e" to go to the home page
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                                     
echo.                                                                                                                      
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input5= └→
if %input5% ==1 goto I1
if %input5% ==2 goto I2
if %input5% ==3 goto I3
if %input5% ==e goto home

:I1
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo SETTINGS - DEVICE INFO - SETTINGS - DEVICE INFO - SETTINGS - DEVICE INFO - SETTINGS - DEVICE INFO - SETTINGS - DEVICE IN
echo.                                                                                                                        
systeminfo
echo press enter
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input6= └→
goto I

:I2
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo SETTINGS - PERSONALIZATION - SETTINGS - PERSONALIZATION - SETTINGS - PERSONALIZATION - SETTINGS - PERSONALIZATION - SETT
echo.                                                                                                                        
echo COLORS
echo.
echo 0 = Black      B = Light Blue
echo 2 = Green      C = Red
echo 5 = Purple     E = Yellow
echo 8 = Grey       F = White
echo 9 = Blue
echo.
echo The first number is the screen color, the second one is the text color
echo.                                                                                                                     
echo.
echo.
echo.
echo.
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input7= └→
del C.bat
echo color %input7% > C.bat
color %input7%
goto I

:I3
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo  SETTINGS - SYSTEM INFO - SETTINGS - SYSTEM INFO - SETTINGS - SYSTEM INFO - SETTINGS - SYSTEM INFO - SETTINGS - SYSTEM I
echo.
echo ▒▓███       ▒▓███ ▒▓██████████████████████████████████████████
echo ▒▓██████ ▒▓██████ ▒▓███
echo ▒▓██████ ▒▓██████ ▒▓███
echo ▒▓███ ▒▓███ ▒▓███ ▒▓██████████████████████████████████████████
echo ▒▓███ ▒▓███ ▒▓███ ▒▓███
echo ▒▓███       ▒▓███ ▒▓███    ▒▓████████████    ▒▓███████████████
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███ ▒▓███
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███ ▒▓███████████████
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███             ▒▓███
echo ▒▓███       ▒▓███ ▒▓███    ▒▓████████████    ▒▓███████████████                                                  ██████
echo.                                                                                                                ██████
echo                                                                                                                 ██████
echo.                                                                                                                     
echo.                                                                                                                ██████
echo MFos 1.0 BETA                                                                                                   ██████
echo Release Date: march 2026                                                                                        ██████
echo Productor (company): BASICS company                                                                             ██████
echo Productor (person): ******* *********                                                                           ██████
echo Code Language: Batch                                                                                    ███     ██████
echo                                                                                                                 ██████
echo                                                                                                    ██   ███     ██████
echo                                                                                                         ███     ██████
echo                                                                                                0   ██   ███     ██████
echo                                                                                                I   ██   ███     ██████
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input8= └→
goto I