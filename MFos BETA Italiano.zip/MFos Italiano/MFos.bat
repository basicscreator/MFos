@echo off
mode con: cols=111 lines=31
chcp 65001
if exist MF.txt goto home
echo Setting Up MFos...
echo quack! > MF.txt
ping localhost -n 5 >nul
echo Loading MFos...
ping localhost -n 5 >nul
color 0f
:home
call C.bat
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Welcome│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo Digita help o h o ? per ricevere la lista di comandi                                                        
echo.                                                                                                                      
echo.                                                                                                                      
echo. 
echo. 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                     
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                     
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo VERSION: 1.0 BETA
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input4= └→
if %input4% ==help goto H
if %input4% ==h goto H
if %input4% ==? goto H
if %input4% ==imp goto I
if %input4% ==calc goto C
if %input4% ==txt goto T
if %input4% ==file goto F
if %input4% ==game goto G
if %input4% ==cmd goto CM
if %input4% ==exi goto E
if %input4% ==mfws goto M
goto home

:E 
cls 
color 0c
echo Stai per spegnere il sistema
echo.
choice /c SN /m "Continuare?"
if errorlevel 2 goto home
if errorlevel 1 exit

:CM
cls 
color 0c
echo Stai per entrare nel prompt comandi, per uscirne digita exit
echo.
choice /c SN /m "Vuoi entrare?"
if errorlevel 2 goto home
if errorlevel 1 cmd

:gugugaga
goto home

:G
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Giochi │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Scegli come vuoi divertirti!
echo.
echo 1.Indovina il numero 
echo 2.Quiz 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                             ██████████
echo.                                                                                          ████░██████░████
echo.                                                                                         ███░██████████░███
echo.                                                                                         ██░█░████████░█░██
echo.                                                                                         ███░██      ██░███
echo.                                                                                         ████          ████
echo.                                                                                         █░░█          █░░█
echo.                                                                                         ████          ████
echo.                                                                                          ██            ██
echo.                                                                                                                      
echo.                                                                                                                      
echo Premi "e" per tornare alla schermata home
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input17= └→
if %input17% ==1 goto IN
if %input17% ==2 goto QZ
if %input17% ==e goto home


:QZ
set punteggio=0
:inizio
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Quiz │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.

REM Domanda 1
echo 1) Qual e la capitale d'Italia?
echo A) Milano
echo B) Roma
echo C) Napoli
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 2
echo.
echo 2) Quanto fa 5x5?
echo A) 20
echo B) 25
echo C) 30
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 3
echo.
echo 3) Colore del cielo sereno?
echo A) Blu
echo B) Verde
echo C) Rosso
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 4
echo.
echo 4) Quanti giorni ha una settimana?
echo A) 5
echo B) 7
echo C) 10
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 5
echo.
echo 5) Qual e un linguaggio di programmazione?
echo A) Python
echo B) Windows
echo C) HTML
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 6
echo.
echo 6) 10 / 2 = ?
echo A) 2
echo B) 5
echo C) 10
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 7
echo.
echo 7) Il sole e una...
echo A) Stella
echo B) Pianeta
echo C) Cometa
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 8
echo.
echo 8) Qual e il contrario di "alto"?
echo A) Basso
echo B) Largo
echo C) Lungo
set /p risposta=
if /i "%risposta%"=="A" set /a punteggio+=1

REM Domanda 9
echo.
echo 9) Quanti mesi ha un anno?
echo A) 10
echo B) 12
echo C) 14
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

REM Domanda 10
echo.
echo 10) Quale animale abbaia?
echo A) Gatto
echo B) Cane
echo C) Pesce
set /p risposta=
if /i "%risposta%"=="B" set /a punteggio+=1

cls
echo ============================
echo        RISULTATO
echo ============================
echo.
echo Hai fatto %punteggio% su 10!

if %punteggio% GEQ 8 (
    echo Ottimo lavoro! 
) else if %punteggio% GEQ 5 (
    echo Buon risultato! 
) else (
    echo Riprova! 
)

echo.
choice /c SN /m "Vuoi rigiocare?"
if errorlevel 2 goto G
if errorlevel 1 goto QZ

:IN
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Indovina Numero │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.
set /a numero=%random% %% 10 + 1
set tentativi=0

:gioca
set /a tentativi+=1
echo.
set /p scelta=Inserisci un numero da 1 a 10: 

if %scelta% LSS %numero% (
    echo Troppo basso!
    goto gioca
)

if %scelta% GTR %numero% (
    echo Troppo alto!
    goto gioca
)

echo.
echo Hai indovinato!
echo Numero: %numero%
echo Tentativi: %tentativi%

echo.
choice /c SN /m "Vuoi rigiocare?"
if errorlevel 2 goto G
if errorlevel 1 goto IN

:F
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Gestore File│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛ 
echo.                                                      
echo -----------------------------------------------------------------------------------------------------------------------
echo Istruzioni Di Navigazione: In alto a sinistra potrai vedere il percorso in cui sei in questo momento (es: "C:\Users\Utente\Desktop\MFos"), poi qui sotto puoi vedere le cartelle presenti nel percorso (es: se sei in desktop e nel tuo desktop c'è una cartella chiamata "Cartella", potrai vedere Cartella dentro a Desktop, come se fosse una sua radice), sotto all'elenco delle cartelle potrai vedere l'elenco dei file presenti nella prima cartella, quella più in alto (es: se sei in desktop vedrai tutti i file presenti in desktop), infine se vuoi cambiare percorso puoi scrivere "cd" e il nome della cartella dove vuoi andare, però puoi andare in una cartella solamente presente nella cartella dove sei in quel momento, quindi se vuoi andare indietro di una cartella devi scrivere cd .. (es: Il percorso è C:Users\Utente\Desktop e tu vuoi andare in MFos che è dentro desktop, scrivi cd MFos. Ma se vuoi andare in Utente che contiene desktop allora scrivi cd ..).
echo.
echo Istruzioni Di Modifica: Se vuoi creare un file allora scrivi "echo (contenuto) > (nome).(tipo di file)", se vuoi eliminare un file allora scrivi "del (nome).(tipo di file)", se vuoi aprirne uno allora scrivi "call (nome).(tipo di file)".
echo.
echo digita "goto home" per tornare alla schermata home
echo -----------------------------------------------------------------------------------------------------------------------
echo Percorso: %cd%
echo.
tree
echo.                                                                                                              
dir                                                                                                                      
echo.                                                                                                                      
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input16= └→
%input16%
goto F

:H
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - HELP│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo LISTA COMANDI                                                        
echo -imp            .Impostazioni 
echo -calc           .Calcolatrice 
echo -txt            .BloccoNotes
echo -file           .Gestore File
echo -game           .Giochi
echo -cmd            .Prompt Dei Comandi
echo -help/h/?       .Aiuto
echo -exit           .Uscire
echo -mfws           .MFwebsearch
echo.                                                                                                                      
echo.                                                                                                ████████████
echo.                                                                                              ████████████████
echo.                                                                                             ████          ████
echo.                                                                                            ████            ████
echo.                                                                                            ████            ████
echo.                                                                                                          ████
echo.                                                                                                         ████
echo.                                                                                                       ████
echo.                                                                                                    ██████
echo.                                                                                                   ████
echo.                                                                                                   ████
echo.                                                                                                   ████
echo.
echo.                                                                                                   ████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p inputP= └→
goto home

:T
call C.bat
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Scegli tra:
echo.
echo 1 - Scrivere un testo 
echo 2 - Leggere un testo
echo 3 - Vedi file 
echo.
echo Digita "e" per tornare alla schermata home
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input13= └→
if "%input13%"=="1" goto scrivi
if "%input13%"=="2" goto leggi
if "%input13%"=="3" goto vedi
if "%input13%"=="e" goto home
goto T

:vedi
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
dir *.txt /b
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input15= └→
goto T

:scrivi
cls
setlocal EnableDelayedExpansion
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Scrivi il nome del file di testo (senza .txt)
echo.
echo.  
echo.  
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set /p nomefile= └→
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Nome file: %nomefile%
echo.
echo Ora scrivi il contenuto, quando hai finito vai a capo e scrivi FINE.  
echo.  
> "%nomefile%.txt" (
    rem crea il file vuoto
)

:loop
set /p riga=
if "!riga!"=="FINE" goto salva
echo !riga!>>"%nomefile%.txt"
goto loop

:salva
endlocal
echo.
echo File "%nomefile%.txt" salvato correttamente!
pause
goto T

:leggi
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
echo Digita il nome del file (senza .txt)
echo.
echo Digita "e" per tornare alla schermata home
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set /p nomefile2=
if not exist "%nomefile2%.txt" (
    echo.
    echo [38;2;255;0;0mERRORE: File non trovato![0m
    pause
    goto T
)

cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - NotePad │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                         
type "%nomefile2%.txt"
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                     ░  ░  ░  ░  ░  ░
echo.                                                                                                   ██░██░██░██░██░██░██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ██ Aa Bb Cc Dd Ee ██
echo.                                                                                                   ██ Ff Gg Hh Ii Jj ██
echo.                                                                                                   ██ Kk Ll Mm Nn Oo ██
echo.                                                                                                   ██ Pp Qq Rr Ss Tt ██
echo.                                                                                                   ██ Uu Vv Zz _____ ██
echo.                                                                                                   ██ Heppi crismas  ██
echo.                                                                                                   ████████████████████
echo.                                                                                                   ████████████████████
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input14= └→
goto T

:C
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Calcolatrice │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Digita un'equazione con + - / *
echo.                                                                                                                      
echo. 
echo. 
echo.                                                                                                              
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                            █████████
echo.
echo.                                                                                            ███ ███
echo.                                                                                              ███
echo.                                                                                            ███ ███       ██████
echo.                                                                                                          ██████
echo.                                                                                                          ██████
echo.                                                                                                    ██████████████████
echo.                                                                                                    ██████████████████
echo.                                                                                                          ██████
echo.                                                                                          ███             ██████
echo.                                                                                         ███              ██████
echo.                                                                                        ███
echo Digita invio per vedere l'equazione precedente                                         ███
echo Digita "e" per tornare alla schermata home 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input11= └→
if %input11% ==e goto home
set/a calc= %input11%
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Calcolatrice │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo Equazione: %input11%
echo Risultato: %calc%
echo. 
echo Se il risultato è identico al risultato dell'equazione precedente o esce un messaggio d'errore, allora l'equazione è 
echo stata digitata incorrettamente
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                            █████████
echo.
echo.                                                                                            ███ ███
echo.                                                                                              ███
echo.                                                                                            ███ ███       ██████
echo.                                                                                                          ██████
echo.                                                                                                          ██████
echo.                                                                                                    ██████████████████
echo.                                                                                                    ██████████████████
echo.                                                                                                          ██████
echo.                                                                                          ███             ██████
echo.                                                                                         ███              ██████
echo.                                                                                        ███
echo.                                                                                       ███
echo Premi invio 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input12= └→
goto C

:M
color 0f
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - MF Web Search│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo premi "e" per tornare alla schermata home
echo.
echo.
echo.
echo.
echo                           [38;2;255;0;0m████            ████   ████████████████████████████████████████████████
echo                           [38;2;255;165;0m████████    ████████   ████████████████████████████████████████████████
echo                           [38;2;255;255;0m████████    ████████   ████
echo                           [38;2;0;255;0m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;255;255m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;0;255m████            ████   ████
echo                           [38;2;255;0;255m████            ████   ████    [38;2;0;255;255m████            ████    [38;2;255;255;0m████████████████
echo                           [38;2;0;0;255m████            ████   ████     [38;2;0;255;255m████          ████     [38;2;255;255;0m████
echo                           [38;2;0;255;255m████            ████   ████      [38;2;0;255;255m████  ████  ████      [38;2;255;255;0m████████████████
echo                           [38;2;0;255;0m████            ████   ████       [38;2;0;255;255m██████████████                   [38;2;255;255;0m████
echo                           [38;2;255;255;0m████            ████   ████        [38;2;0;255;255m████    ████        [38;2;255;255;0m████████████████
echo.
echo                            [38;2;255;255;0m███ ███ ███ █   ███ ███ ███    █  █   [38;2;0;255;255m█ █  █ ███ ██ ███ █  █ ███ ███
echo                            [38;2;255;255;0m█   █   █ █ █   █ █ █ █ █ █    █  █   [38;2;0;255;255m█ ██ █  █  █  █ █ ██ █ █    █
echo                            [38;2;255;255;0m███ ███ ███ █   █ █ ███ █ █    █      [38;2;0;255;255m█ █ ██  █  ██ ███ █ ██ ███  █
echo                            [38;2;255;255;0m█     █ █   █   █ █ ██  ███    █      [38;2;0;255;255m█ █  █  █  █  ██  █  █ █    █
echo                            [38;2;255;255;0m███ ███ █   ███ ███ █ █ █ █    ███    [38;2;0;255;255m█ █  █  █  ██ █ █ █  █ ███  █ [0m
echo.
echo.
echo Digita l'indirizzo di un [38;2;0;255;255msito web[0m e [38;2;255;255;0mesplora[0m il mondo [38;2;0;255;255minformatico![0m [38;2;255;0;0m(ATTENZIONE, L'INDIRIZZO DEVE INIZIARE CON https://)[0m
echo.
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input9= └→
if %input9% ==e goto home

:ananananana
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - MF Web Search│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo.                                                        
echo --- MFWS - Powered By : Any Browser Your Device Uses ------------------------------------------------------------------
echo.
echo.  
echo Se il link viene mostrato sottolineato allora funziona, se non allora o è errato oppure non esiste
echo.                                                                                                              
echo.                                                                                                                      
echo Indirizzo: %input9% [38;2;255;0;0m(Per entrare, posizionare il mouse sul link e poi premere Ctrl + LMC)[0m 
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.                                                                                                                      
echo.
echo.
echo                           [38;2;255;0;0m████            ████   ████████████████████████████████████████████████
echo                           [38;2;255;165;0m████████    ████████   ████████████████████████████████████████████████
echo                           [38;2;255;255;0m████████    ████████   ████
echo                           [38;2;0;255;0m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;255;255m████    ████    ████   ████████████████████████████████████████████████
echo                           [38;2;0;0;255m████            ████   ████
echo                           [38;2;255;0;255m████            ████   ████    [38;2;0;255;255m████            ████    [38;2;255;255;0m████████████████
echo                           [38;2;0;0;255m████            ████   ████     [38;2;0;255;255m████          ████     [38;2;255;255;0m████
echo                           [38;2;0;255;255m████            ████   ████      [38;2;0;255;255m████  ████  ████      [38;2;255;255;0m████████████████
echo                           [38;2;0;255;0m████            ████   ████       [38;2;0;255;255m██████████████                   [38;2;255;255;0m████
echo                           [38;2;255;255;0m████            ████   ████        [38;2;0;255;255m████    ████        [38;2;255;255;0m████████████████[0m
echo. 
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input10= └→
goto M


:I
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo  IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI - IMPOSTAZIONI -
echo.
echo INFO DISPOSITIVO 1
echo.
echo PERSONALIZZAZIONE 2
echo.
echo INFO SISTEMA 3
echo.
echo premi "e" per tornare alla schermata home
echo.
echo.
echo.
echo.
echo.
echo.                                                                                                                     
echo.                                                                                                                      
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input5= └→
if %input5% ==1 goto I1
if %input5% ==2 goto I2
if %input5% ==3 goto I3
if %input5% ==e goto home

:I1
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo IMPOSTAZIONI - INFO DISPOSITIVO - IMPOSTAZIONI - INFO DISPOSITIVO - IMPOSTAZIONI - INFO DISPOSITIVO - IMPOSTAZIONI - INF
echo.                                                                                                                        
systeminfo
echo premi invio
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input6= └→
goto I

:I2
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo IMPOSTAZIONI - PERSONALIZZAZIONE - IMPOSTAZIONI - PERSONALIZZAZIONE - IMPOSTAZIONI - PERSONALIZZAZIONE - IMPOSTAZIONI -
echo.                                                                                                                        
echo COLORI
echo.
echo 0 = Nero      B = Azzurro
echo 2 = Verde     C = Rosso
echo 5 = Viola     E = Giallo
echo 8 = Grigio    F = Bianco
echo 9 = Blu
echo.
echo Il primo numero digitato farà da sfondo, il secondo da testo
echo.                                                                                                                     
echo Su alcune app il colore del testo rimarrà bianco per problemi di coding
echo.
echo.
echo.
echo                                                                                                                    ████
echo                                                                                                                    ████
echo                                                                                                      ████          ████
echo                                                                                                     ███████    ████████
echo                                                                                                       █████████████████
echo                                                                                                         ███████████████
echo                                                                                                        ███████████
echo                                                                                                      ███████████
echo                                                                                              █████████████████      ███
echo                                                                                              █████████████████    ██
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input7= └→
del C.bat
echo color %input7% > C.bat
color %input7%
goto I

:I3
cls
echo ╒╡░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ MFos - Settings│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░╞╕
echo ╘═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╛
echo  IMPOSTAZIONI - INFO SISTEMA - IMPOSTAZIONI - INFO SISTEMA - IMPOSTAZIONI - INFO SISTEMA - IMPOSTAZIONI - INFO SISTEMA -
echo.
echo ▒▓███       ▒▓███ ▒▓██████████████████████████████████████████
echo ▒▓██████ ▒▓██████ ▒▓███
echo ▒▓██████ ▒▓██████ ▒▓███
echo ▒▓███ ▒▓███ ▒▓███ ▒▓██████████████████████████████████████████
echo ▒▓███ ▒▓███ ▒▓███ ▒▓███
echo ▒▓███       ▒▓███ ▒▓███    ▒▓████████████    ▒▓███████████████
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███ ▒▓███
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███ ▒▓███████████████
echo ▒▓███       ▒▓███ ▒▓███ ▒▓███          ▒▓███             ▒▓███
echo ▒▓███       ▒▓███ ▒▓███    ▒▓████████████    ▒▓███████████████                                                  ██████
echo.                                                                                                                ██████
echo                                                                                                                 ██████
echo.                                                                                                                     
echo.                                                                                                                ██████
echo MFos 1.0 BETA                                                                                                   ██████
echo Release Date: march 2026                                                                                        ██████
echo Productor (company): BASICS company                                                                             ██████
echo Productor (person): ******* *********                                                                           ██████
echo Code Language: Batch                                                                                    ███     ██████
echo                                                                                                                 ██████
echo                                                                                                    ██   ███     ██████
echo                                                                                                         ███     ██████
echo                                                                                                0   ██   ███     ██████
echo                                                                                                I   ██   ███     ██████
echo ╒╡░Input░╞════════════════════════════════════════════════════════════════════════════════════════════════════════════╕
set/p input8= └→
goto I